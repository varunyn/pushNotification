define([], () => {
  'use strict';

  class PageModule {
  }

    const checkPermission = () => {
    if (!('serviceWorker' in navigator)) {
      throw new Error("No support for service worker!");
    }

    if (!('Notification' in window)) {
      throw new Error("No support for notification API");
    }

    if (!('PushManager' in window)) {
      throw new Error("No support for Push API");
    }
  };

  const registerSW = async (path) => {
    let registration;
    if ('serviceWorker' in navigator && 'PushManager' in window) {
      registration = await navigator.serviceWorker.register(path + 'sw.js').then(serviceWorkerRegistration => {
        console.info('Service worker was registered.');
        console.info({ serviceWorkerRegistration });
      }).catch(error => {
        console.error('An error occurred while registering the service worker.');
        console.error(error);
      });
    } else {
      console.error('Browser does not support service workers or push messages.');
    }
    return registration;
  };

  const requestNotificationPermission = async () => {
    const permission = await Notification.requestPermission();

    if (permission !== 'granted') {
      throw new Error("Notification permission not granted");
    }

  };

  PageModule.prototype.main = async (path) => {
    checkPermission();
    await requestNotificationPermission();
    await registerSW(path);
  };
  
  return PageModule;
});
